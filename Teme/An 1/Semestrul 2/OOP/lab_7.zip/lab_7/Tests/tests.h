//
// Created by Știube Denis on 29.03.2024.
//

#ifndef LAB_6_PB_7_TESTS_H
#define LAB_6_PB_7_TESTS_H

#include <assert.h>
#include "/Users/stiubedenis/Desktop/Facultate/Teme/Semestrul 2/OOP/lab_7/Service/service.h"
#include "/Users/stiubedenis/Desktop/Facultate/Teme/Semestrul 2/OOP/lab_7/List/list.h"
#include "/Users/stiubedenis/Desktop/Facultate/Teme/Semestrul 2/OOP/lab_7/List/iterator.h"

void testAll();

#endif //LAB_6_PB_7_TESTS_H

