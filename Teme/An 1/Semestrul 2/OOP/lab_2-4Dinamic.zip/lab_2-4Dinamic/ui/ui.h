//
// Created by Știube Denis on 18.03.2024.
//

#ifndef LAB_2_4_UI_H
#define LAB_2_4_UI_H

void Afisare(ListaOferte);

void AdaugaOfertaUI(ListaOferte*);

void StergeOfertaUI(ListaOferte*);

void ModificaOfertaUI(ListaOferte*);

void SortarePretOfertaUI(ListaOferte*);

void SortareDataOfertaUI(ListaOferte*);

void FiltruPretUI(ListaOferte);

void FiltruTipUI(ListaOferte);

void FiltruDataUI(ListaOferte);

void Meniu();

void run(ListaOferte*);

#endif //LAB_2_4_UI_H
