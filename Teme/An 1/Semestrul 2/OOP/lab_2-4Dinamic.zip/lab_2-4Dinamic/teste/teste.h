//
// Created by Știube Denis on 09.03.2024.
//
#ifndef TESTE_H_
#define TESTE_H_

/*
 * Contine toate testele aferente functionalitatilor
 */
void AllTests();

#endif