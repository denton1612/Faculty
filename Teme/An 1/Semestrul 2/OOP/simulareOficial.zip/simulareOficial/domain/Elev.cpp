//
// Created by Știube Denis on 20.05.2024.
//

#include "Elev.h"

bool Elev::operator==(Elev &el) {
    return nrMatricol == el.nrMatricol;
}