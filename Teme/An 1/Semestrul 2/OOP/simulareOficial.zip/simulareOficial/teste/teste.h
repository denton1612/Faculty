//
// Created by Știube Denis on 20.05.2024.
//

#ifndef SIMULAREOFICIAL_TESTE_H
#define SIMULAREOFICIAL_TESTE_H
#include "../domain/Elev.h"
#include "../utils/utils.h"
#include "../repository/Lista.h"
#include "../service/Service.h"
#include "assert.h"

void testAll();

#endif //SIMULAREOFICIAL_TESTE_H
