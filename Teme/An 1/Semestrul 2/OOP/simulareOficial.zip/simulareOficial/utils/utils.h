//
// Created by Știube Denis on 20.05.2024.
//

#ifndef SIMULAREOFICIAL_UTILS_H
#define SIMULAREOFICIAL_UTILS_H
#include <string>
using namespace std;

// transforma un string in intreg
int to_int(string & s);

#endif //SIMULAREOFICIAL_UTILS_H
