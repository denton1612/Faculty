#include "IteratorDictionar.h"
#include "Dictionar.h"

using namespace std;

IteratorDictionar::IteratorDictionar(const Dictionar& d) : dict(d){
	this->curent = d.prim;
}


void IteratorDictionar::prim() {
	curent = dict.prim;
}

void IteratorDictionar::urmator() {
	curent = curent->urmator();
}

void IteratorDictionar::precedent() {
    curent = curent->precedent();
}

TElem IteratorDictionar::element() const{
    if (!valid())
	    return TElem (-1, -1);
    return curent->elem();
}

bool IteratorDictionar::valid() const {
	if (curent != nullptr)
        return true;
	return false;
}

